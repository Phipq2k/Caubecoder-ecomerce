@extends('admin_layout')
@section('admin_content')
<style type="text/css">
  ul.top-menu>li>a{
    background: black;
  }
</style>
<div class="table-agile-info">
    <div class="panel panel-default">
      <div class="panel-heading">
        Danh sách bài viết
      </div>
      <div class="row w3-res-tb">
        <div class="col-sm-5 m-b-xs">
          <select class="input-sm form-control w-sm inline v-middle">
            <option value="0">Bulk action</option>
            <option value="1">Delete selected</option>
            <option value="2">Bulk edit</option>
            <option value="3">Export</option>
          </select>
          <button class="btn btn-sm btn-default">Apply</button>                
        </div>
        <div class="col-sm-4">
        </div>
        <div class="col-sm-3">
          <div class="input-group">
            <input type="text" class="input-sm form-control" placeholder="Search">
            <span class="input-group-btn">
              <button class="btn btn-sm btn-default" type="button">Go!</button>
            </span>
          </div>
        </div>
      </div>
      <div class="table-responsive">
        <?php
            $i = 0;
	        	$messages = Session::get('message');
	        	if($messages){
	        		echo '<span class="text-alert">'.$messages.'</span>';
	        		Session::put('message', null);	
	        	}	
	        ?>
        <table class="table table-striped b-t b-light">
          <thead>
            <tr>
              <th style="width:20px;">
               STT
              </th>
              <th>Tên bài viết</th>
              <th>Slug</th>
              <th>Hình ảnh bài viết</th>
              <th>Từ khóa tìm kiếm</th>
              <th>Tóm tắt bài viết</th>
              <th>Mô tả bài viết</th>
              <th>Danh mục bài viết</th>
              <th>Nội dung bài viết</th>
              <th>Hiển thị</th>
              <th style="width:30px;">Chức năng</th>
            </tr>
          </thead>
          <tbody>
            @foreach ($allPost as $key => $posts)
            @php
              $i++;
            @endphp
            <tr>
              <td>{{$i}}</td>
              <td>{{$posts->post_title}}</td>
              <td>{{$posts->post_slug}}</td>
              <td><img src="storage/app/public/uploads/posts/{{$posts->post_image}}" height="100px" width="100px"alt="image"/></td>
              <td>{{$posts->post_meta_keywords}}</td>
              <td>{{$posts->post_desc}}</td>
              <td>{{$posts->post_meta_desc}}</td>
              <td>{{$posts->cate_post_name}}</td>
              <td>{!!$posts->post_content!!}</td>
              <td>
                <span class="text-ellipsis">
                  <?php
                    if ($posts->post_status == 0){
                      ?>
                       <span class="text-danger fa-thumb-styling fa fa-thumbs-down"></span>
                  <?php
                    }else{
                      ?>
                      <span class="text-success fa-thumb-styling fa fa-thumbs-up"></span>
                        
                    <?php }?>
              </td>
              <td>
                <div class="nav notify-row" style="width: 85%"id="top_menu">
                  <ul class="nav top-menu">
                      <li class="dropdown">
                        <a title="Chỉnh sửa bài viết" href="{{URL::to('/edit-post/'.$posts->post_id)}}"  class="active styling-edit" ui-toggle-class="">
                          <i class="fa fa-pencil-square-o text text-primary"></i>
                        </a>
                      </li>
                  </ul>
                </div>
                <div class="nav notify-row" style="width: 85%"id="top_menu">
                  <ul class="nav top-menu">
                      <li class="dropdown">
                        <a title="Xóa bài viết" onclick="return confirm('Bạn có chắc là muốn xóa bài viết này không?')" href="{{URL::to('/delete-post/'.$posts->post_id)}}" class="active styling-edit" ui-toggle-class="">
                          <i class="fa fa-times text-danger text"></i>
                        </a>
                      </li>
                  </ul>
                </div>
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
      <footer class="panel-footer">
        <div class="row">
          
          <div class="col-sm-5 text-center">
            <small class="text-muted inline m-t-sm m-b-sm">showing 20-30 of 50 items</small>
          </div>
          <div class="col-sm-7 text-right text-center-xs">                
            <ul class="pagination pagination-sm m-t-none m-b-none">
              {!!$allPost->links()!!}
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
@endsection
